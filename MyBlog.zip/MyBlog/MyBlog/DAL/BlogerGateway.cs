﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MyBlog.Model;
using System.Configuration;
using System.Data.SqlClient;

namespace MyBlog.DAL
{
    public class BlogerGateway
    {
        string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
        public int Insert(Blg blg) {
            SqlConnection connection = new SqlConnection(connectionString);

            string query = "INSERT INTO tbl_posts(Title,Description,CreatedDate) VALUES('" + blg.Title + "', '" + blg.Description + "','"+blg.CreatedDate+"')";
            //insert student
            SqlCommand command = new SqlCommand(query, connection);

            connection.Open();

            int rowAffected = command.ExecuteNonQuery();

            connection.Close();

            return rowAffected;
        }
    }
}