﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MyBlog.Model;
using MyBlog.BLL;

namespace MyBlog
{
    public partial class SubmitBlog : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        BlogManager manager = new BlogManager();
       protected void saveButton_Click(object sender, EventArgs e)
       {

         // Session["Name"].ToString();
       
               Blg ablog = new Blg();
               ablog.Title = titleTextBox.Text;
               ablog.Description = Request.Form["edit"].ToString();
               ablog.CreatedDate = DateTime.Now;
               manager.Insert(ablog);
           

       }
    }
}