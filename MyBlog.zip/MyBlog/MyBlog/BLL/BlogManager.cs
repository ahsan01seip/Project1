﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MyBlog.DAL;
using MyBlog.Model;

namespace MyBlog.BLL
{
    public class BlogManager
    {
        BlogerGateway gateway = new BlogerGateway();
        public string Insert(Blg blg)
        {
            if (gateway.Insert(blg) > 0)
            {
                return "Successful";
            }

            else {
                return "Sorry";
            }
        }

    }    

}